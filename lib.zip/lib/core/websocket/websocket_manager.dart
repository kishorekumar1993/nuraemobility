// lib/core/websocket/websocket_manager.dart
import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../../models/message.dart';
import '../logger/logger.dart';
import 'socket_status.dart';

typedef OnMessageReceived = void Function(Message message);
typedef OnStatusChange = void Function(SocketStatus status);

/// Enterprise‑grade WebSocket manager with auto‑reconnect, deduplication, and status tracking.
class WebSocketManager {
  final String _url;
  final Duration _initialReconnectDelay;
  final Duration _maxReconnectDelay;
  final int _maxRetries;
  final Duration _connectionTimeout;

  WebSocketChannel? _channel;
  StreamSubscription? _subscription;
  Timer? _reconnectTimer;
  int _reconnectAttempts = 0;
  bool _isReconnecting = false;
  bool _isDisposed = false;

  // Message deduplication store (by counter)
  final Map<int, Message> _receivedMessages = {};

  // Status stream
  final _statusController = StreamController<SocketStatus>.broadcast();
  Stream<SocketStatus> get statusStream => _statusController.stream;
  SocketStatus _currentStatus = SocketStatus.disconnected;

  // Incoming message stream (already deduplicated and parsed)
  final _messageController = StreamController<Message>.broadcast();
  Stream<Message> get messageStream => _messageController.stream;

  // Callback for when missing counters are detected (triggers polling)
  Function(List<int> missingCounters)? onMissingCounters;

  WebSocketManager({
    required String url,
    Duration initialReconnectDelay = const Duration(seconds: 1),
    Duration maxReconnectDelay = const Duration(seconds: 30),
    int maxRetries = 5,
    Duration connectionTimeout = const Duration(seconds: 10),
  })  : _url = url,
        _initialReconnectDelay = initialReconnectDelay,
        _maxReconnectDelay = maxReconnectDelay,
        _maxRetries = maxRetries,
        _connectionTimeout = connectionTimeout;

  // --------------------------------------------------------------------------
  // Public API
  // --------------------------------------------------------------------------
  void connect() {
    if (_isDisposed) {
      AppLogger.error('WebSocketManager already disposed');
      return;
    }
    if (_channel != null) {
      AppLogger.warning('WebSocket already connecting/connected, closing first');
      disconnect();
    }
    _setStatus(SocketStatus.connecting);
    _connectWithTimeout();
  }

  void disconnect() {
    _cancelReconnectTimer();
    _reconnectAttempts = 0;
    _isReconnecting = false;
    _subscription?.cancel();
    _subscription = null;
    _channel?.sink.close();
    _channel = null;
    _setStatus(SocketStatus.disconnected);
    AppLogger.info('WebSocket disconnected manually');
  }

  void sendMessage(String message) {
    if (_channel != null && _currentStatus == SocketStatus.connected) {
      _channel!.sink.add(message);
      AppLogger.debug('Sent: $message');
    } else {
      AppLogger.warning('Cannot send, WebSocket not connected');
    }
  }

  void dispose() {
    _isDisposed = true;
    disconnect();
    _statusController.close();
    _messageController.close();
    _receivedMessages.clear();
  }

  // --------------------------------------------------------------------------
  // Core connection logic
  // --------------------------------------------------------------------------
  void _connectWithTimeout() {
    Future.wait([
      _connectInternal(),
      Future.delayed(_connectionTimeout),
    ]).then((result) {
      // If _connectInternal finishes first, ok. Otherwise timeout triggers.
    }).catchError((e) {
      if (e is TimeoutException) {
        AppLogger.error('WebSocket connection timeout after ${_connectionTimeout.inSeconds}s');
        _handleConnectionFailure();
      }
    });
  }

  Future<void> _connectInternal() async {
    try {
      _channel = WebSocketChannel.connect(Uri.parse(_url));
      _setStatus(SocketStatus.connecting);

      // Listen to incoming messages
      _subscription = _channel!.stream.listen(
        _onMessage,
        onError: _onError,
        onDone: _onDone,
      );

      // Wait a moment to confirm connection
      await Future.delayed(Duration(milliseconds: 500));
      if (!_isDisposed && _channel != null) {
        _setStatus(SocketStatus.connected);
        _reconnectAttempts = 0;
        _isReconnecting = false;
        AppLogger.info('WebSocket connected to $_url');
      }
    } catch (e) {
      AppLogger.error('WebSocket connection failed', error: e);
      _handleConnectionFailure();
    }
  }

  void _onMessage(dynamic data) {
    try {
      final json = jsonDecode(data as String) as Map<String, dynamic>;
      final message = Message.fromJson(json);

      // Deduplicate
      if (_receivedMessages.containsKey(message.counter)) {
        AppLogger.debug('Duplicate message ignored: ${message.counter}');
        return;
      }

      // Store and emit
      _receivedMessages[message.counter] = message;
      _messageController.add(message);
      AppLogger.info('Message received #${message.counter}: ${message.echoMessage}');

      // Optional: detect gaps (missing counters) – triggers polling
      _checkForGaps(message.counter);
    } catch (e) {
      AppLogger.error('Failed to parse WebSocket message: $data', error: e);
    }
  }

  void _onError(Object error, StackTrace stack) {
    AppLogger.error('WebSocket error', error: error, stack: stack);
    _handleConnectionFailure();
  }

  void _onDone() {
    AppLogger.info('WebSocket closed');
    if (!_isDisposed && _currentStatus != SocketStatus.disconnected) {
      _handleConnectionFailure();
    } else {
      _setStatus(SocketStatus.disconnected);
    }
  }

  void _handleConnectionFailure() {
    _subscription?.cancel();
    _channel = null;
    _setStatus(SocketStatus.error);
    _scheduleReconnect();
  }

  // --------------------------------------------------------------------------
  // Reconnection logic with exponential backoff
  // --------------------------------------------------------------------------
  void _scheduleReconnect() {
    if (_isDisposed) return;
    if (_reconnectAttempts >= _maxRetries) {
      AppLogger.error('Max reconnection attempts ($_maxRetries) reached, giving up');
      _setStatus(SocketStatus.disconnected);
      return;
    }

    _isReconnecting = true;
    final delay = _calculateBackoffDelay(_reconnectAttempts);
    AppLogger.info('Scheduling reconnect attempt ${_reconnectAttempts + 1} in ${delay.inSeconds}s');

    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(delay, () {
      if (!_isDisposed) {
        _reconnectAttempts++;
        _setStatus(SocketStatus.reconnecting);
        _connectInternal();
      }
    });
  }

  Duration _calculateBackoffDelay(int attempt) {
    final exponential = _initialReconnectDelay * (1 << attempt); // 2^attempt
    if (exponential > _maxReconnectDelay) return _maxReconnectDelay;
    return exponential;
  }

  void _cancelReconnectTimer() {
    _reconnectTimer?.cancel();
    _reconnectTimer = null;
  }

  // --------------------------------------------------------------------------
  // Gap detection (missing counters)
  // --------------------------------------------------------------------------
  int _lastReceivedCounter = 0;

  void _checkForGaps(int currentCounter) {
    if (currentCounter > _lastReceivedCounter + 1) {
      final missing = List<int>.generate(
        currentCounter - _lastReceivedCounter - 1,
            (i) => _lastReceivedCounter + i + 1,
      );
      AppLogger.warning('Missing counters detected: $missing');
      onMissingCounters?.call(missing);
    }
    _lastReceivedCounter = currentCounter;
  }

  // --------------------------------------------------------------------------
  // Status management
  // --------------------------------------------------------------------------
  void _setStatus(SocketStatus newStatus) {
    if (_currentStatus == newStatus) return;
    _currentStatus = newStatus;
    _statusController.add(newStatus);
    AppLogger.info('WebSocket status: $newStatus');
  }

  // --------------------------------------------------------------------------
  // Utility: get all received messages (ordered)
  // --------------------------------------------------------------------------
  List<Message> getReceivedMessages() {
    final sorted = _receivedMessages.values.toList();
    sorted.sort((a, b) => a.counter.compareTo(b.counter));
    return sorted;
  }

  /// Resets deduplication store (useful after full poll sync)
  void resetStore() {
    _receivedMessages.clear();
    _lastReceivedCounter = 0;
  }
}