// lib/core/websocket/socket_status.dart
enum SocketStatus {
  connecting,
  connected,
  disconnected,
  reconnecting,
  error,
}