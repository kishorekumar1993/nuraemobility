//
// import 'package:dio/dio.dart';
// import 'api_client.dart';
//
// typedef RefreshTokenCallback = Future<String> Function();
//
// /// Automatically retry failed requests with a new token.
// class TokenInterceptor extends Interceptor {
//   final ApiClient apiClient;
//   final RefreshTokenCallback refreshToken;
//   bool _isRefreshing = false;
//   final List<RequestOptions> _pendingRequests = [];
//
//   TokenInterceptor({
//     required this.apiClient,
//     required this.refreshToken,
//   });
//
//   @override
//   void onError(DioException err, ErrorInterceptorHandler handler) async {
//     if (err.response?.statusCode == 401 && !_isRefreshing) {
//       _isRefreshing = true;
//       try {
//         final newToken = await refreshToken();
//         apiClient.setToken(newToken);
//         _retryPendingRequests(newToken);
//         _isRefreshing = false;
//         handler.resolve(await _retry(err.requestOptions));
//       } catch (e) {
//         _isRefreshing = false;
//         handler.next(err);
//       }
//     } else if (err.response?.statusCode == 401 && _isRefreshing) {
//       _pendingRequests.add(err.requestOptions);
//       handler.next(err);
//     } else {
//       handler.next(err);
//     }
//   }
//
//   Future<Response> _retry(RequestOptions options) async {
//     final newOptions = options.copyWith(
//       headers: {
//         ...options.headers,
//         'Authorization': 'Bearer ${apiClient.toString()}',
//       },
//     );
//     return Dio().fetch(newOptions);
//   }
//
//   void _retryPendingRequests(String newToken) {
//     for (final options in _pendingRequests) {
//       _retry(options);
//     }
//     _pendingRequests.clear();
//   }
// }